<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class presenting_gift extends Model
{
     protected $table = 'presenting_gift';
}
