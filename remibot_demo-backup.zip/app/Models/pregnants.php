<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class pregnants extends Model
{
     protected $table = 'pregnants';
}
