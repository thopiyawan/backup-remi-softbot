<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class quizstep extends Model
{
    protected $table = 'quizstep';
}
