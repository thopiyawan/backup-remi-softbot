<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RecordOfPregnancy extends Model
{
    protected $table = 'RecordOfPregnancy';
}
