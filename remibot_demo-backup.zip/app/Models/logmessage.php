<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class logmessage extends Model
{
    protected $table = 'log_message';
}
