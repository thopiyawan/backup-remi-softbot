<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class foodmenu_img extends Model
{
    protected $table = 'foodmenu_img';
}
